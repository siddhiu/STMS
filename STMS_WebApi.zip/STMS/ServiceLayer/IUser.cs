﻿using DomainLayer.Models.BindingModel;
using STMS.Models;
using System;
using System.Threading.Tasks;
using System.Web.Http;

namespace ServiceLayer
{
    public interface IUser
    {
        //RegisterUser
        Task<object> RegisterUser([FromBody]EmployeeRegistration model);
        //GetAllUser
        Task<object> GetAllUsers();
        //Login
        Task<object> Login([FromBody]Login model);
        //AddRole
        Task<Object> AddRole([FromBody]AddRoleBindingModel model);
        //GetRoles
        Task<object> GetRoles();
        //GenerateToken
        //string GenerateToken(AppUser user, string role);
    }
}
