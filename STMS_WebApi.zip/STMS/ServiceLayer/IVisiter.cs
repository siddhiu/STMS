﻿using DomainLayer.Models;
using DomainLayer.Models.BindingModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer
{
    public interface IVisiter
    {
        //AddCourse
        string AddVisitor(VisitTable visitor);

        //GetCourses
        List<VisitTable> GetAllVisitors();

        //GetSingleCourse
        VisitTable GetSingleVisitor(long id);

        //UpdateCourse
        string UpdateVisitor(VisitTable visitor);

        //Delete Course
        string RemoveVisitor(int id);

    }
}
