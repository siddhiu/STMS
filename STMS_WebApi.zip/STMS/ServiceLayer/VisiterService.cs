﻿using DomainLayer.Models;
using DomainLayer.Models.BindingModel;
using RepositoryLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer
{
    public class VisiterService : IVisiter
    {
        private readonly STMSContext _dbContext;
        public VisiterService(STMSContext dbContext)
        {
            this._dbContext = dbContext;
        }
        
        public string AddVisitor(VisitTable visitor)
        {
            try
            {
                this._dbContext.Courses.Add(visitor);
                this._dbContext.SaveChanges();
                return "Visiter Added Successfully";
            }
            catch(Exception ex)
            {
                return ex.Message;
            }
        }

        public List<VisitTable> GetAllVisitors()
        {
            return this._dbContext.Courses.ToList();
        }

        public VisitTable GetSingleVisitor(long id)
        {
            return this._dbContext.Courses.Where(x => x.VisitId == id).FirstOrDefault();
        }

        public string RemoveVisitor(int id)
        {
            try
            {
                var C = this._dbContext.Courses.Find(id);
                this._dbContext.Remove(C);
                this._dbContext.SaveChanges();
                return "Visiter Deleted Successfully";
            }
            catch(Exception ex)
            {
                return ex.Message;
            }
        }


        public string UpdateVisitor(VisitTable course)
        {
            try
            {
                var C = this._dbContext.Courses.Find(course.VisitId);
                if (C != null)
                {
                    C.CustName = course.CustName;
                    C.ContactPerson = course.ContactPerson;
                    C.ContactNo = course.ContactNo;
                    C.InterestProduct = course.InterestProduct;
                    C.VisitSubject = course.VisitSubject;
                    C.Descrip = course.Descrip;
                    C.VisitDate = course.VisitDate;
                    C.IsDisabled = course.IsDisabled;
                    C.IsDeleted = course.IsDeleted;



                    this._dbContext.SaveChanges();
                    return "Course Updated Successfully";
                }
                else
                    return "No Record Found";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
    }
}
