﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using DomainLayer.Models.BindingModel;
using STMS.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using RepositoryLayer.Entities;
using Microsoft.AspNetCore.Identity;

namespace DomainLayer.Models.BindingModel
//namespace STMS.Models
{
    public partial class STMSContext : IdentityDbContext<AppUser, IdentityRole, string>
    {
        public STMSContext(DbContextOptions<STMSContext> options) : base(options)
        {
        }
        public DbSet<VisitTable> Courses { get; set; }
    }
}
