﻿using DomainLayer.Models.BindingModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RepositoryLayer.Entities;
using ServiceLayer;
using STMS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace STMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUser _user;
        public UserController(IUser user)
        {
            this._user = user;

        }

        //RegisterUser
        [HttpPost("Register")]
        public async Task<object> RegisterUser([FromBody] EmployeeRegistration model)
        {
            return Ok(await _user.RegisterUser(model));
        }

        [HttpPost("Login")]
        public async Task<object> Login([FromBody] Login model)
        {
          return Ok(await _user.Login(model));
        }

        [HttpPost("AddType")]
        public async Task<Object> AddRole([FromBody] AddRoleBindingModel model)
        {
            return Ok(await _user.AddRole(model));
        }

        [Authorize(Roles = "Admin")]
        [HttpGet("GetAllUsers")]
        
        public async Task<object> GetAllUsers()
        {
            return Ok(await _user.GetAllUsers());
        }
    }
}
