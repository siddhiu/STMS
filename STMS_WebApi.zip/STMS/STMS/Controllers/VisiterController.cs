﻿using DomainLayer.Models;
using DomainLayer.Models.BindingModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ServiceLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace STMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VisiterController : ControllerBase
    {
        private readonly IVisiter _visitor;
        public VisiterController(IVisiter visitor)
        {
            this._visitor = visitor;
        }

        //GetAllCourse
        [HttpGet]
        public IActionResult GetAllVisitors()
        {
            var response = this._visitor.GetAllVisitors();
            return Ok(response);
        }

        //GetSingleRecord
        // [HttpGet("get/{id:int}")]
        [HttpGet("{id}")]
        public IActionResult GetSingleVisitor(long id)
        {
            return Ok(this._visitor.GetSingleVisitor(id));
        }

        [HttpPost]
        public IActionResult AddVisitor(VisitTable visitor)
        {
            return Ok(this._visitor.AddVisitor(visitor));
        }

        [HttpDelete("{id}")]
        public IActionResult RemoveVisitor(int id)
        {
            return Ok(this._visitor.RemoveVisitor(id));
        }

        [HttpPut]
        public IActionResult UpdateVisitor(VisitTable visitor)
        {
            return Ok(this._visitor.UpdateVisitor(visitor));
        }
    }
}
