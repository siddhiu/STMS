﻿using DomainLayer.Models.BindingModel;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#nullable disable

namespace STMS.Models
{
    public partial class EmployeeRegistration
    {
        public EmployeeRegistration()
        {
            VisitTables = new HashSet<VisitTable>();
        }
        [Key]
        public int EmpId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmpEmail { get; set; }
        public string Pass { get; set; }
        public int Age { get; set; }
        public string Gender { get; set; }
        public string Addr { get; set; }
        public string PhoneNumber { get; set; }
        public string UserType { get; set; } = "User";

        public virtual ICollection<VisitTable> VisitTables { get; set; }
    }
}
